module Main where

import qualified Jq.Main as J (main)

main :: IO ()
main = J.main
